/*Q1 A Angelina Sun 500521854*/

SELECT year, COUNT(*) AS "count_of_flights"
FROM aircrafts 
INNER JOIN flights ON flights.tail_number = aircrafts.tail_number
GROUP BY year
HAVING year is not null
ORDER BY count_of_flights DESC
LIMIT 1;

/* Q1 B Vighnesh Deshpande 490532430*/


select count(flight_number) count_of_late_arrivals, airport_name 
from flights
left outer join airports on flights.destination= airports.airport_code
where actual_arrival_time > scheduled_arrival_time group by airport_name 
order by count(*) desc 
limit 1;




/* Q1 C Steven Li 500517721*/

SELECT state, 
sum(number_flights) as "number_of_flights" from
	(select state, count(airport_code) as "number_flights" 
 	from airports right join flights on airports.airport_code = flights.origin
 	group by state
 	having state is not null
 	union all
 	select state, count(airport_code) as "number_flights"
 	from airports right join flights on airports.airport_code = flights.destination
 	group by state
 	having state is not null) all_results
group by state
ORDER BY number_of_flights
limit 1;



/* Q1 D Ruifeng He 490440009*/

SELECT Aircrafts.tail_number, Aircrafts.manufacturer, Aircrafts.model, SUM(Flights.distance) AS total_distance 
FROM Flights
JOIN Aircrafts
ON Flights.tail_number = Aircrafts.tail_number

GROUP BY Aircrafts.tail_number, Aircrafts.manufacturer, Aircrafts.model 
order by total_distance desc
Limit 1;



/* Q2 */

(select name, round(cast(sum(case when actual_departure_time > scheduled_departure_time then 1 else 0 end)*1.0 /count(Flights.carrier_code) as decimal(8,4))*100,2) || '%' as rate_departed_late , 
round(cast(sum(case when actual_arrival_time > scheduled_arrival_time then 1 else 0 end)*1.0 /count(Flights.carrier_code) as decimal(8,4))*100,2) || '%' as rate_arrival_late
from Flights inner join Airlines
using (carrier_code)
where name is not null 
group by name
order by rate_departed_late desc
limit 1)

UNION ALL

(select name, round(cast(sum(case when actual_departure_time > scheduled_departure_time then 1 else 0 end)*1.0 /count(Flights.carrier_code) as decimal(8,4))*100,2) || '%' as rate_departed_late , 
round(cast(sum(case when actual_arrival_time > scheduled_arrival_time then 1 else 0 end)*1.0 /count(Flights.carrier_code) as decimal(8,4))*100,2) || '%' as rate_arrival_late
from Flights inner join Airlines
using (carrier_code)
where name is not null 
group by name
order by rate_arrival_late desc
Limit 1)



/* Q3 */

select airport_code, 
	airport_name, 
	sum(distance) as "this_airport_distance", 
	(select avg(the_sum) 
		from (select sum(distance) as "the_sum" 
			from flights
			group by origin) avee) as 
			"average_distance_overall",
	count(distinct carrier_code) as "number_of_carriers"

from flights left join airports 
	on flights.origin = airports.airport_code 
group by airport_code
having sum(distance) > (select avg(the_sum) from 
(select sum(distance) as "the_sum"from flights
				group by origin) avee)
order by number_of_carriers
limit 1;